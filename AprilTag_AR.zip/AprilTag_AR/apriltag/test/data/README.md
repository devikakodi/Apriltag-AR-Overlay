Test image from NASA Swarmathon competition at KSC. Licenced under "CC BY-SA 2.0 DEED".

Sources:
- https://www.flickr.com/photos/nasakennedy/33369213973/
- https://www.flickr.com/photos/nasakennedy/34085369442/
- https://www.flickr.com/photos/nasakennedy/34139872896/
